#
# xHpcPackInstall: DSC resource to install HPC Pack.
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint = "",

        # For HeadNode only
        [string] $ClusterName = "",

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )

    return $PSBoundParameters
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint = "",

        # For HeadNode only
        [string] $ClusterName = "",

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )

    $downloader = New-Object System.Net.WebClient
    # Download the setup package if it is an http/https url
    if($SetupPkgPath -match "^https?://")
    {
        $setupPkgUrl = $SetupPkgPath
        $SetupPkgPath = Join-Path "$env:windir\Temp" $($setupPkgUrl -split '/')[-1]
        DownloadFile -Downloader $downloader -SourceUrl $setupPkgUrl -DestPath $SetupPkgPath
    }

    if((Test-Path -Path $SetupPkgPath -PathType Leaf) -and [IO.Path]::GetExtension($SetupPkgPath) -eq ".zip")
    {
        $basetgtdir = $SetupPkgPath.Substring(0, $SetupPkgPath.LastIndexOf('.')) + '_HPC'
        $tgtdir = $basetgtdir
        $index = 0
        while(Test-Path -Path $tgtdir -PathType Container)
        {
            try
            {
                Remove-Item -Path $tgtdir -Recurse -Force -ErrorAction Stop
                break
            }
            catch
            {
                $tgtdir = "$basetgtdir" + "_$index"
            }
        }

        [System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem') | Out-Null
        [System.IO.Compression.ZipFile]::ExtractToDirectory($SetupPkgPath, $tgtdir) | Out-Null
    }
    else
    {
        $tgtdir = $SetupPkgPath
    }

    $pfxCert = Get-Item Cert:\LocalMachine\My\$SSLThumbprint -ErrorAction SilentlyContinue
    if($pfxCert -eq $null)
    {
        throw "No certificate specified"
    }

    if($pfxCert.Subject -eq $pfxCert.Issuer)
    {
        if(-not (Test-Path Cert:\LocalMachine\Root\$SSLThumbprint))
        {
            TraceVerbose "Installing certificate to Cert:\LocalMachine\Root"
            $cerFileName = "$env:Temp\HpcPackComm.cer"
            Export-Certificate -Cert "Cert:\LocalMachine\My\$SSLThumbprint" -FilePath $cerFileName | Out-Null
            Import-Certificate -FilePath $cerFileName -CertStoreLocation Cert:\LocalMachine\Root  | Out-Null
            Remove-Item $cerFileName -Force -ErrorAction SilentlyContinue
        }
    }

    if($NodeType -eq "HeadNode")
    {
        $setupArg = "-unattend -Quiet -HeadNode -HeadNodeList:`"$HeadNodeList`" -ClusterName:$ClusterName -SSLThumbprint:$SSLThumbprint"
        if(-not [string]::IsNullOrEmpty($SQLServerInstance))
        {
            $mgmtConstr = "Data Source=$SQLServerInstance;Initial Catalog=HpcManagement;Integrated Security=True;"
            $schdConstr = "Data Source=$SQLServerInstance;Initial Catalog=HpcScheduler;Integrated Security=True;"
            $monConstr  = "Data Source=$SQLServerInstance;Initial Catalog=HPCMonitoring;Integrated Security=True;"
            $rptConstr  = "Data Source=$SQLServerInstance;Initial Catalog=HPCReporting;Integrated Security=True;"
            $diagConstr = "Data Source=$SQLServerInstance;Initial Catalog=HPCDiagnostics;Integrated Security=True;"
            $setupArg = "$setupArg -MGMTDBCONSTR:`"$mgmtConstr`" -SCHDDBCONSTR:`"$schdConstr`" -RPTDBCONSTR:`"$rptConstr`" -DIAGDBCONSTR:`"$diagConstr`" -MONDBCONSTR:`"$monConstr`""           
        }
    }
    elseif($NodeType -eq "HeadNodePreReq")
    {
        $setupArg = "-unattend -Quiet -HeadNodePreReq -SSLThumbprint:$SSLThumbprint"
    }
    else
    {
        $setupArg = "-unattend -Quiet -${NodeType}:`"$HeadNodeList`" -SSLThumbprint:$SSLThumbprint"
    }

    $retry = 0
    while($retry -lt 10)
    {
        TraceVerbose ("Installing HPC $NodeType")
        $p = Start-Process -FilePath "$tgtdir\setup.exe" -ArgumentList $setupArg -PassThru -Wait
        if($p.ExitCode -eq 0)
        {
            TraceVerbose ("Succeed to Install HPC $NodeType")
            break
        }
        TraceVerbose ("Failed to Install HPC $NodeType, return code is " + $p.ExitCode)
        Start-Sleep -Seconds 20
        $retry++
    }
    if($retry -eq 10)
    {
        throw "Failed to install $NodeType in $env:ComputerName"
    }
}

function Test-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint = "",

        # For HeadNode only
        [string] $ClusterName = "",

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )
    
    $clientGuid = "186B7E1A-6C30-46AB-AB83-4AE925377838"
    $serverGuid = "02985CCE-D7D5-40FF-9C81-6334523210F9"
    if(@("ComputeNode", "BrokerNode", "WorkstationNode") -contains $NodeType)
    {
        $serverProp = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ?{$_.UninstallString -and $_.UninstallString -match $serverGuid}
        return ($null -ne $serverProp)
    }
    else
    {
        if(-not [System.Diagnostics.PerformanceCounterCategory]::Exists('HPC Scheduler'))
        {
            return $false
        }
        $clientGuid = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ?{$_.UninstallString -and $_.UninstallString -match $clientGuid}
        if($NodeType -eq "HeadNodePreReq")
        {
            return ($null -ne $clientGuid)        
        }
        else
        {
            $fabricSvc = Get-Service -Name 'fabricHostSvc' -ErrorAction SilentlyContinue
            return (($null -ne $fabricSvc) -and ($null -ne $clientGuid))
        }
    }
}

function DownloadFile
{
    param(
        [parameter(Mandatory = $false)]
        [System.Net.WebClient] $Downloader = $null,

        [parameter(Mandatory = $true)]
        [string] $SourceUrl,

        [parameter(Mandatory = $true)]
        [string] $DestPath
    )

    if($Downloader -eq $null)
    {
        $Downloader = New-Object System.Net.WebClient
    }

    $fileName = $($SourceUrl -split '/')[-1]
    if(Test-Path -Path $DestPath -PathType Container)
    {
        $DestPath = [IO.Path]::Combine($DestPath, $fileName)
    }

    $downloadRetry = 0
    while($true)
    {
        try
        {
            if(Test-Path -Path $DestPath)
            {
                Remove-Item -Path $DestPath -Force -Confirm:$false -ErrorAction SilentlyContinue
            }

            TraceVerbose "Downloading $SourceUrl to $DestPath(Retry=$downloadRetry)."
            $Downloader.DownloadFile($SourceUrl, $DestPath)
            TraceVerbose "Downloaded $SourceUrl to $DestPath."
            break
        }
        catch
        {
            if($downloadRetry -lt 10)
            {
                TraceVerbose ("Failed to download files, retry after 20 seconds:" + $_)
                Clear-DnsClientCache
                Start-Sleep -Seconds 20
                $downloadRetry++
            }
            else
            {
               throw "Failed to download files after 10 retries"
            }
        }
    }
}

function TraceVerbose
{
    param(
    [string] $Message
    )

    Write-Verbose "$(Get-Date -format yyyy-MM-dd_HH-mm-ss) $Message"
}

Export-ModuleMember -Function *-TargetResource
