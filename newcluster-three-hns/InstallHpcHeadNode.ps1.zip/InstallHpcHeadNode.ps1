﻿configuration InstallHpcHeadNode 
{ 
   param 
   ( 
        [Parameter(Mandatory = $true)]
        [String]$DomainName,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [string] $SetupPkgPath = 'C:\HPCPack2016Preview',

        [parameter(Mandatory = $true)]
        [string] $ClusterName,

        [parameter(Mandatory = $false)]
        [string] $SQLServerInstance = "",

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=30,

        [String]$PostConfigScript = ""
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xHpcPack, xNetworking
    $DomainNetBiosName = $DomainName.Split('.')[0]
    $ADUserName = "${DomainNetBiosName}\$($Admincreds.UserName)"
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ($ADUserName, $Admincreds.Password)
    $PostConfigScript = $PostConfigScript.Trim()
    $otherheadnodes = @($HeadNodeList -split ',' | ?{$_ -ne $env:COMPUTERNAME})
    $otherHN1 = $otherheadnodes[0].Trim()
    $otherHN2 = $otherheadnodes[1].Trim()
    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xFirewall AllowRemoteAdminIn
        {
            Name = "remote-administration-in"
            DisplayName = "Remote administration In"
            Ensure = "Present"
            Action = "Allow"
            Direction = "Inbound"
            Protocol = "TCP"
            LocalPort = @(445)
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        Group AddADUserToLocalAdminGroup
        {
            GroupName = 'Administrators'   
            Ensure = 'Present'             
            MembersToInclude= $ADUserName
            Credential = $DomainCreds    
            DependsOn = "[xComputer]DomainJoin"
        }

        if($NodeType -eq 'HeadNodePreReq')
        {
            xHpcPackInstall InstallHeadNodePreReq
            {
                NodeType = $NodeType
                HeadNodeList = $HeadNodeList
                SetupPkgPath = $SetupPkgPath
                SSLThumbprint = $SSLThumbprint
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[Group]AddADUserToLocalAdminGroup" 
            }

            Script WaitForFabricSvc
            {
                GetScript = {
                    return @{
                        Result = $true
                    }
                }
            
                SetScript = {
                    $i = 0
                    while($i -lt 60)
                    {
                        $fabricSvc = Get-Service -Name 'fabricHostSvc' -ErrorAction SilentlyContinue
                        if($fabricSvc -ne $null -and $fabricSvc.Status -eq 'Running')
                        {
                            if(Test-Path HKLM:\SOFTWARE\Microsoft\HPC)
                            {
                                $installedRoles = Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\HPC -Name InstalledRole -ErrorAction SilentlyContinue
                                if($null -ne $installedRoles -and ($installedRoles.InstalledRole -contains 'HN'))
                                {
                                    Write-Verbose "HPC fabric application is now running"
                                    break;
                                }
                            }

                            Write-Verbose "fabricHostSvc is running, but the HPC fabric application is not started yet..."
                        }
                        else
                        {
                            Write-Verbose "fabricHostSvc is not running yet, wait ..."
                        }

                        Start-Sleep -Seconds 20
                    }
                }
            
                TestScript = {
                    if(Test-Path HKLM:\SOFTWARE\Microsoft\HPC)
                    {
                        $installedRoles = Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\HPC -Name InstalledRole -ErrorAction SilentlyContinue
                        if($null -ne $installedRoles -and ($installedRoles.InstalledRole -contains 'HN'))
                        {
                            return $true
                        }
                    }

                    return $false
                }
            
                DependsOn = "[xHpcPackInstall]InstallHeadNodePreReq"       
            }

            xHpcPackInstall InstallComputeNode
            {
                NodeType = "ComputeNode"
                HeadNodeList = $HeadNodeList
                SetupPkgPath = $SetupPkgPath
                SSLThumbprint = $SSLThumbprint
                DependsOn = "[Script]WaitForFabricSvc","[xHpcPackInstall]InstallHeadNodePreReq"
            }
        }

        if($NodeType -eq 'HeadNode')
        {
            cWaitForADComputer WaitForHeadNode1
            {
                ComputerName = $otherHN1
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[Group]AddADUserToLocalAdminGroup" 
            }

            cWaitForADComputer WaitForHeadNode2
            {
                ComputerName = $otherHN2
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[Group]AddADUserToLocalAdminGroup" 
            }

            xHpcPackInstall InstallHeadNode
            {
                NodeType = $NodeType
                HeadNodeList = $HeadNodeList
                SetupPkgPath = $SetupPkgPath
                SSLThumbprint = $SSLThumbprint
                ClusterName = $ClusterName
                SQLServerInstance = $SQLServerInstance
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[cWaitForADComputer]WaitForHeadNode1","[cWaitForADComputer]WaitForHeadNode2"
            }

            xHpcPackInstall InstallComputeNode
            {
                NodeType = "ComputeNode"
                HeadNodeList = $HeadNodeList
                SetupPkgPath = $SetupPkgPath
                SSLThumbprint = $SSLThumbprint
                DependsOn = "[xHpcPackInstall]InstallHeadNode"
            }
        }

        Script PostConfig
        {
            GetScript = {
                return @{
                    Result = $true
                }
            }
            
            SetScript = Format-PostConfigScriptBlock -PostConfigScript $PostConfigScript -DomainUserName $DomainCreds.UserName -scriptBlock {
                $TrimmedScript = @"
{PostConfigScriptPlaceholder}
"@
                $UserName = @"
{DomainUserNamePlaceholder}
"@
                $TrimmedScript = $TrimmedScript.Trim()
                $firstSpace = $TrimmedScript.IndexOf(' ')
                if($firstSpace -gt 0)
                {
                    $scriptUrl = $TrimmedScript.Substring(0, $firstSpace)
                    $scriptArgs = $TrimmedScript.Substring($firstSpace + 1).Trim()
                }
                else
                {
                    $scriptUrl = $TrimmedScript
                    $scriptArgs = ""
                }

                if(-not [system.uri]::IsWellFormedUriString($scriptUrl,[System.UriKind]::Absolute) -or $scriptUrl -notmatch '[^/]/[^/]+\.ps1$')
                {
                    throw  "Invalid url or not PowerShell script: $scriptUrl"
                }

                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if($null -ne $env:CCP_DATA)
                {
                    $HPCTempRoot = [IO.Path]::Combine($env:CCP_DATA, "LogFiles\HPC-$machineId")
                }
                else
                {
                    $HPCTempRoot = "$env:windir\Temp\HPC-$machineId"
                }
                if(-not (Test-Path -Path $HPCTempRoot))
                {
                    New-Item -Path $HPCTempRoot -ItemType directory -Confirm:$false -Force
                    $acl = Get-Acl $HPCTempRoot
                    $acl.SetAccessRuleProtection($true, $false)
                    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM","FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
                    $acl.AddAccessRule($rule)
                    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
                    $acl.AddAccessRule($rule)
                    try
                    {
                        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($UserName, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
                        $acl.AddAccessRule($rule)
                    }
                    catch
                    {
                        Write-Warning -Message "Failed to grant access permissions for user '$UserName': $($_ | Out-String)"
                    }

                    Set-Acl -Path $HPCTempRoot -AclObject $acl -Confirm:$false
                }

                $executionResultFile = "$HPCTempRoot\PostConfigScriptExecution.flag"
                # Output the command line to PostConfigScriptExecution.result
                $TrimmedScript | Out-File $executionResultFile -Confirm:$false -Force

                $scriptFileName = $($scriptUrl -split '/')[-1]
                $scriptFilePath = "$HPCTempRoot\$scriptFileName"
                $downloader = New-Object System.Net.WebClient
                $downloadRetry = 0
                while($true)
                {
                    try
                    {
                        Write-Verbose -Message "Downloading custom script file from $scriptUrl to $scriptFilePath(Retry=$downloadRetry)."
                        $downloader.DownloadFile($scriptUrl, $scriptFilePath)
                        Write-Verbose -Message "Downloaded custom script file from $scriptUrl to $scriptFilePath."
                        break
                    }
                    catch
                    {
                        if($downloadRetry -lt 10)
                        {
                            Write-Verbose -Message  ("Failed to download $scriptUrl, retry after 20 seconds:" + $_)
                            Clear-DnsClientCache
                            Start-Sleep -Seconds 20
                            $downloadRetry++
                        }
                        else
                        {
                            Write-Error -Message "Failed to download $scriptUrl after 10 retries"
                            "Failed to download $scriptUrl" | Out-File $executionResultFile -Confirm:$false -Force -Append
                            return
                        }
                    }
                }

                # Sometimes the new process failed to run due to system not ready, we try to create a test file to check whether the process works
                $testFileName = "$HPCTempRoot\HPCPostConfigScriptTest."  + (Get-Random)
                if(-not $scriptArgs.Contains(' *> '))
                {
                    $logFilePath = [IO.Path]::ChangeExtension($scriptFilePath, $null) + (Get-Date -Format "yyyy_MM_dd-hh_mm_ss") + ".log"
                    $scriptArgs += " *> `"$logFilePath`""
                }
                $scriptCmd = "'test' | Out-File '$testFileName' -Confirm:`$false -Force;& '$scriptFilePath' $scriptArgs"
                $encodedCmd = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($scriptCmd))
                $scriptRetry = 0
                while($true)
                {
                    $pobj = Invoke-WmiMethod -Path win32_process -Name Create -ArgumentList "PowerShell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand $encodedCmd"
                    if($pobj.ReturnValue -eq 0)
                    {
                        Start-Sleep -Seconds 5
                        if(Test-Path -Path $testFileName)
                        {
                            # Remove the test file
                            Remove-Item -Path $testFileName -Confirm:$false -Force -ErrorAction Continue
                            Write-Verbose -Message "Started to run $scriptFilePath, output file at $logFilePath."
                            "Started $scriptRetry : $scriptFilePath $scriptArgs" | Out-File $executionResultFile -Confirm:$false -Force -Append
                            break
                        }
                        else
                        {
                            Write-Verbose -Message "The new process failed to run, stop it."
                            Stop-Process -Id $pobj.ProcessId
                        }
                    }
                    else
                    {
                        Write-Verbose -Message "Failed to start powershell process to run custom script (Retry=$scriptRetry)."
                    }

                    if($scriptRetry -lt 10)
                    {
                        $scriptRetry++
                        Start-Sleep -Seconds 10
                    }
                    else
                    {
                        throw "Failed to start powershell process to run custom script."
                    }
                }
            }
            
            TestScript = Format-PostConfigScriptBlock -PostConfigScript $PostConfigScript -scriptBlock  {
                $TrimmedScript = @"
{PostConfigScriptPlaceholder}
"@
                $TrimmedScript = $TrimmedScript.Trim()
                if([string]::IsNullOrEmpty($TrimmedScript))
                {
                    return $true
                }

                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if($null -ne $env:CCP_DATA)
                {
                    $HPCTempRoot = [IO.Path]::Combine($env:CCP_DATA, "LogFiles\HPC-$machineId")
                }
                else
                {
                    $HPCTempRoot = "$env:windir\Temp\HPC-$machineId"
                }
                $executionResultFile = "$HPCTempRoot\PostConfigScriptExecution.flag"
                if(Test-Path -Path $executionResultFile)
                {
                    $lines = @(Get-Content $executionResultFile)
                    if($lines.Count -gt 0)
                    {
                        return $lines[0] -eq $TrimmedScript
                    }
                }

                return $false
            }

            DependsOn = "[xHpcPackInstall]InstallComputeNode"
        }

   }
} 

function Format-PostConfigScriptBlock
{
    param(
        [parameter(Mandatory=$false)]
        [string] $PostConfigScript = "",

        [parameter(Mandatory=$false)]
        [string] $DomainUserName = "",

        [parameter(Mandatory=$true)]
        [System.Management.Automation.ScriptBlock] $scriptBlock
    )

    $result = $scriptBlock.ToString()
    $result = $result.Replace("{PostConfigScriptPlaceholder}", $PostConfigScript)
    $result = $result.Replace("{DomainUserNamePlaceholder}", $DomainUserName)
    return $result
}